const Auxillary = (props) => props.children;

export default Auxillary;
