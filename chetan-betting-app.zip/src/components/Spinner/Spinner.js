import React from "react";
import "./Spinner.css";
const Spinner = () => {
    return <div className="Loader">Loading...</div>;
};

export default Spinner;
